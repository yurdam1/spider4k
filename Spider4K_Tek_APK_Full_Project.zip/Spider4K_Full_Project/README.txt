Spider4K Full Android Project

1) Android Studio ile bu klasörü aç.
2) İnternet bağlantısı açık olsun.
3) Build > Build APK(s) seç.
4) APK yolu: app/build/outputs/apk/debug/app-debug.apk

API adresleri MainActivity.java içinde hazır:
https://efeemir.site/spider4k/api/check_mac.php
https://efeemir.site/spider4k/api/content.php
